#include <stdio.h>

void print()
{
    printf("this is print\n");
}
