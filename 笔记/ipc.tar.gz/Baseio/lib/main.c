#include <stdio.h>
#include "child.h"

int main()
{
    print();
    return 0;
}

